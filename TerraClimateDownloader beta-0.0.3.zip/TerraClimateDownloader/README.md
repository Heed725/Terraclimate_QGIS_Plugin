# TerraClimate Downloader for QGIS

**Version 0.0.3**

Download and clip TerraClimate climate data directly in QGIS. Simply select your area of interest and choose the climate variable and year you need.

## Easy Installation

### Method 1: Install from ZIP (Recommended)

1. Download the `TerraClimateDownloader-0.0.3.zip` file
2. In QGIS, go to **Plugins → Manage and Install Plugins**
3. Click **Install from ZIP**
4. Select the downloaded ZIP file and click **Install Plugin**
5. After installation, go to **Plugins → TerraClimate Downloader → Install Dependencies**
6. Click **Install Required Packages** and wait for completion
7. **Restart QGIS**
8. You're ready to use the plugin!

### Method 2: Manual Installation

1. Extract the ZIP file
2. Copy the `TerraClimateDownloader` folder to your QGIS plugins directory:
   - **Windows:** `C:\Users\<username>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - **macOS:** `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
   - **Linux:** `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
3. Restart QGIS
4. Enable the plugin in **Plugins → Manage and Install Plugins**
5. Install dependencies as described above

## Installing Python Dependencies

The plugin requires additional Python packages. There are two ways to install them:

### Automatic (Recommended)
1. Go to **Plugins → TerraClimate Downloader → Install Dependencies**
2. Click **Install Required Packages**
3. Restart QGIS after installation

### Manual Installation

**Windows (OSGeo4W Shell):**
```bash
python -m pip install xarray rioxarray numpy netCDF4
```

**macOS/Linux (Terminal):**
```bash
# Find your QGIS Python
/Applications/QGIS.app/Contents/MacOS/bin/python3 -m pip install xarray rioxarray numpy netCDF4
# or on Linux:
python3 -m pip install xarray rioxarray numpy netCDF4
```

## How to Use

1. Load a **polygon layer** representing your area of interest
2. Open the tool:
   - **Plugins → TerraClimate Downloader → Open TerraClimate Downloader**
   - Or find it in the **Processing Toolbox** under "TerraClimate Downloader"
3. Configure:
   - Select your boundary layer
   - Choose a climate variable
   - Select the year (1958-2024)
   - Choose month (-1 for all months, 1-12 for specific month)
   - Set output file location
4. Click **Run**

## Available Climate Variables

| Variable | Description | Units |
|----------|-------------|-------|
| aet | Actual Evapotranspiration | mm |
| def | Climatic Water Deficit | mm |
| pdsi | Palmer Drought Severity Index | - |
| pet | Potential Evapotranspiration | mm |
| ppt | Precipitation | mm |
| q | Runoff | mm |
| soil | Soil Moisture | mm |
| srad | Downward Shortwave Radiation | W/m² |
| swe | Snow Water Equivalent | mm |
| tmax | Maximum Temperature | °C |
| tmin | Minimum Temperature | °C |
| vap | Vapor Pressure | kPa |
| vpd | Vapor Pressure Deficit | kPa |
| ws | Wind Speed | m/s |

## Troubleshooting

### "Missing Python packages" error
- Use the built-in dependency installer: **Plugins → TerraClimate Downloader → Install Dependencies**
- Restart QGIS after installing packages

### Connection timeout
- Check your internet connection
- The TerraClimate server may be temporarily unavailable
- Increase the "Connection retries" parameter

### Large area downloads are slow
- TerraClimate data is downloaded over the internet
- Consider downloading smaller regions or single months
- The plugin only downloads the data you need, but large areas still take time

## Credits

- **Author:** Hemed Lungo (Hemedlungo@gmail.com)
- **Icon:** Fusion5085
- **TerraClimate Dataset:** Abatzoglou, J.T., S.Z. Dobrowski, S.A. Parks, K.C. Hegewisch (2018). TerraClimate, a high-resolution global dataset of monthly climate and climatic water balance from 1958-2015. Scientific Data.

## Links

- [GitHub Repository](https://github.com/Heed725/Terraclimate_QGIS_Plugin/)
- [TerraClimate Website](https://www.climatologylab.org/terraclimate.html)
- [Report Issues](https://github.com/Heed725/Terraclimate_QGIS_Plugin/issues)

## License

See LICENSE file for details.
