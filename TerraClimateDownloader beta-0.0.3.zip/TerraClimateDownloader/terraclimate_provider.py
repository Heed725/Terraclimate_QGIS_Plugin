# -*- coding: utf-8 -*-
"""
TerraClimate Provider - Processing provider and plugin management
Version 0.0.3
"""
import os
import sys
import subprocess
import importlib

from qgis.PyQt.QtCore import QCoreApplication, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAction, QMessageBox, QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QProgressBar, QApplication
)
from qgis.core import QgsProcessingProvider, QgsApplication, Qgis

PLUGIN_PROVIDER_ID = "terraclimate_downloader"
PLUGIN_VERSION = "0.0.3"

# Required packages with pip install names
REQUIRED_PACKAGES = {
    "xarray": "xarray",
    "rioxarray": "rioxarray",
    "numpy": "numpy",
}

# Optional packages (nice to have for better performance)
OPTIONAL_PACKAGES = {
    "netCDF4": "netCDF4",
    "dask": "dask",
}


def check_package(module_name):
    """Check if a Python package is available."""
    try:
        importlib.import_module(module_name)
        return True
    except ImportError:
        return False


def get_missing_packages():
    """Get lists of missing required and optional packages."""
    missing_required = []
    missing_optional = []
    
    for module, pip_name in REQUIRED_PACKAGES.items():
        if not check_package(module):
            missing_required.append((module, pip_name))
    
    for module, pip_name in OPTIONAL_PACKAGES.items():
        if not check_package(module):
            missing_optional.append((module, pip_name))
    
    return missing_required, missing_optional


class DependencyInstallerDialog(QDialog):
    """Dialog for installing Python dependencies."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("TerraClimate - Install Dependencies")
        self.setMinimumWidth(600)
        self.setMinimumHeight(400)
        self.setup_ui()
        self.check_status()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header = QLabel("<h2>TerraClimate Downloader - Dependency Setup</h2>")
        layout.addWidget(header)
        
        # Status label
        self.status_label = QLabel("Checking dependencies...")
        layout.addWidget(self.status_label)
        
        # Progress bar
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)
        
        # Log output
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("font-family: monospace; font-size: 11px;")
        layout.addWidget(self.log_output)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        self.install_btn = QPushButton("Install Required Packages")
        self.install_btn.clicked.connect(self.install_packages)
        btn_layout.addWidget(self.install_btn)
        
        self.install_all_btn = QPushButton("Install All (incl. Optional)")
        self.install_all_btn.clicked.connect(lambda: self.install_packages(include_optional=True))
        btn_layout.addWidget(self.install_all_btn)
        
        self.refresh_btn = QPushButton("Refresh Status")
        self.refresh_btn.clicked.connect(self.check_status)
        btn_layout.addWidget(self.refresh_btn)
        
        self.close_btn = QPushButton("Close")
        self.close_btn.clicked.connect(self.accept)
        btn_layout.addWidget(self.close_btn)
        
        layout.addLayout(btn_layout)
        
        # Help text
        help_text = QLabel(
            "<small><b>Note:</b> If automatic installation fails, you can install manually:<br>"
            "<code>python -m pip install xarray rioxarray numpy netCDF4</code><br>"
            "Run this in the OSGeo4W Shell (Windows) or terminal (Mac/Linux).</small>"
        )
        help_text.setWordWrap(True)
        layout.addWidget(help_text)
    
    def log(self, message):
        """Add message to log output."""
        self.log_output.append(message)
        QApplication.processEvents()
    
    def check_status(self):
        """Check and display dependency status."""
        self.log_output.clear()
        missing_req, missing_opt = get_missing_packages()
        
        self.log("=" * 50)
        self.log("DEPENDENCY STATUS CHECK")
        self.log("=" * 50)
        self.log("")
        
        # Check required packages
        self.log("REQUIRED PACKAGES:")
        all_required_ok = True
        for module, pip_name in REQUIRED_PACKAGES.items():
            if check_package(module):
                self.log(f"  ✓ {module} - installed")
            else:
                self.log(f"  ✗ {module} - NOT INSTALLED")
                all_required_ok = False
        
        self.log("")
        self.log("OPTIONAL PACKAGES (for better performance):")
        for module, pip_name in OPTIONAL_PACKAGES.items():
            if check_package(module):
                self.log(f"  ✓ {module} - installed")
            else:
                self.log(f"  ○ {module} - not installed")
        
        self.log("")
        self.log("=" * 50)
        
        # Update status label
        if all_required_ok:
            self.status_label.setText(
                "<span style='color: green; font-weight: bold;'>✓ All required dependencies are installed!</span>"
            )
            self.status_label.setStyleSheet("padding: 10px; background-color: #d4edda; border-radius: 5px;")
            self.install_btn.setEnabled(False)
            self.log("Ready to use! You can close this dialog.")
        else:
            self.status_label.setText(
                "<span style='color: red; font-weight: bold;'>✗ Missing required dependencies - click 'Install Required Packages'</span>"
            )
            self.status_label.setStyleSheet("padding: 10px; background-color: #f8d7da; border-radius: 5px;")
            self.install_btn.setEnabled(True)
    
    def get_pip_executable(self):
        """Find the correct pip executable for QGIS Python."""
        # Try different approaches to find pip
        python_exe = sys.executable
        
        # Try pip as a module first (most reliable)
        return [python_exe, "-m", "pip"]
    
    def install_packages(self, include_optional=False):
        """Install missing packages using pip."""
        missing_req, missing_opt = get_missing_packages()
        
        packages_to_install = [pip_name for _, pip_name in missing_req]
        if include_optional:
            packages_to_install.extend([pip_name for _, pip_name in missing_opt])
        
        if not packages_to_install:
            self.log("\nNo packages need to be installed!")
            return
        
        self.log("")
        self.log("=" * 50)
        self.log("INSTALLING PACKAGES")
        self.log("=" * 50)
        self.log(f"Packages to install: {', '.join(packages_to_install)}")
        self.log("")
        
        # Disable buttons during installation
        self.install_btn.setEnabled(False)
        self.install_all_btn.setEnabled(False)
        self.refresh_btn.setEnabled(False)
        
        self.progress.setVisible(True)
        self.progress.setRange(0, len(packages_to_install))
        self.progress.setValue(0)
        
        pip_cmd = self.get_pip_executable()
        success_count = 0
        
        for i, package in enumerate(packages_to_install):
            self.log(f"\nInstalling {package}...")
            QApplication.processEvents()
            
            try:
                # Build install command
                cmd = pip_cmd + ["install", "--user", package]
                self.log(f"  Command: {' '.join(cmd)}")
                
                # Run pip install
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=300  # 5 minute timeout per package
                )
                
                if result.returncode == 0:
                    self.log(f"  ✓ {package} installed successfully!")
                    success_count += 1
                else:
                    self.log(f"  ✗ Failed to install {package}")
                    self.log(f"  Error: {result.stderr[:500] if result.stderr else 'Unknown error'}")
                    
                    # Try without --user flag
                    self.log(f"  Retrying without --user flag...")
                    cmd_no_user = pip_cmd + ["install", package]
                    result2 = subprocess.run(cmd_no_user, capture_output=True, text=True, timeout=300)
                    if result2.returncode == 0:
                        self.log(f"  ✓ {package} installed successfully (system-wide)!")
                        success_count += 1
                    else:
                        self.log(f"  ✗ Still failed. Manual installation may be required.")
                
            except subprocess.TimeoutExpired:
                self.log(f"  ✗ Installation timed out for {package}")
            except Exception as e:
                self.log(f"  ✗ Error installing {package}: {str(e)}")
            
            self.progress.setValue(i + 1)
            QApplication.processEvents()
        
        self.log("")
        self.log("=" * 50)
        self.log(f"Installation complete: {success_count}/{len(packages_to_install)} packages")
        self.log("=" * 50)
        
        if success_count == len(packages_to_install):
            self.log("\n✓ All packages installed! Please RESTART QGIS for changes to take effect.")
            QMessageBox.information(
                self,
                "Installation Complete",
                "All packages were installed successfully!\n\n"
                "Please RESTART QGIS for the changes to take effect."
            )
        else:
            self.log("\n⚠ Some packages failed to install. See manual instructions below.")
        
        # Re-enable buttons
        self.install_btn.setEnabled(True)
        self.install_all_btn.setEnabled(True)
        self.refresh_btn.setEnabled(True)
        self.progress.setVisible(False)
        
        # Refresh status
        self.check_status()


class TerraClimateProvider(QgsProcessingProvider):
    """Processing provider for TerraClimate algorithms."""
    
    def icon(self):
        return QIcon(os.path.join(os.path.dirname(__file__), 'icon.svg'))

    def loadAlgorithms(self):
        # Only load algorithm if dependencies are available
        missing_req, _ = get_missing_packages()
        if not missing_req:
            from .terraclimate_algorithm import TerraClimateClipByYear_GDAL
            self.addAlgorithm(TerraClimateClipByYear_GDAL())

    def id(self):
        return PLUGIN_PROVIDER_ID

    def name(self):
        return self.tr("TerraClimate Downloader")

    def longName(self):
        return self.name()

    def tr(self, text):
        return QCoreApplication.translate("TerraClimateProvider", text)


class TerraClimateProviderPlugin:
    """Main plugin class - registers provider and manages menu entries."""
    
    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.actions = []
        self.menu_name = "TerraClimate Downloader"
        self.toolbar = None
        self.icon_path = os.path.join(os.path.dirname(__file__), "icon.svg")
    
    def initGui(self):
        """Initialize the plugin GUI."""
        # Create toolbar
        self.toolbar = self.iface.addToolBar(self.menu_name)
        self.toolbar.setObjectName("TerraClimateToolbar")
        
        # Check dependencies
        missing_req, _ = get_missing_packages()
        deps_ok = len(missing_req) == 0
        
        # Register processing provider
        self.provider = TerraClimateProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)
        
        # Main tool action
        icon = QIcon(self.icon_path) if os.path.exists(self.icon_path) else QIcon()
        
        if deps_ok:
            action_text = "Open TerraClimate Downloader"
            action_tooltip = "Download and clip TerraClimate climate data"
        else:
            action_text = "Open TerraClimate Downloader (Setup Required)"
            action_tooltip = "Click to set up dependencies first"
        
        self.action_open = QAction(icon, action_text, self.iface.mainWindow())
        self.action_open.setToolTip(action_tooltip)
        self.action_open.triggered.connect(self.open_tool_dialog)
        self.iface.addPluginToMenu(self.menu_name, self.action_open)
        self.toolbar.addAction(self.action_open)
        self.actions.append(self.action_open)
        
        # Install dependencies action
        self.action_install = QAction(
            QIcon.fromTheme("system-software-install"),
            "Install Dependencies...",
            self.iface.mainWindow()
        )
        self.action_install.setToolTip("Install required Python packages for TerraClimate Downloader")
        self.action_install.triggered.connect(self.show_installer_dialog)
        self.iface.addPluginToMenu(self.menu_name, self.action_install)
        self.actions.append(self.action_install)
        
        # Help/About action
        self.action_help = QAction(
            QIcon.fromTheme("help-about"),
            "About / Help",
            self.iface.mainWindow()
        )
        self.action_help.triggered.connect(self.show_help)
        self.iface.addPluginToMenu(self.menu_name, self.action_help)
        self.actions.append(self.action_help)
        
        # Show notification if dependencies are missing
        if not deps_ok:
            self.iface.messageBar().pushMessage(
                "TerraClimate Downloader",
                "Setup required! Go to Plugins → TerraClimate Downloader → Install Dependencies",
                level=Qgis.Warning,
                duration=10
            )
    
    def unload(self):
        """Unload the plugin."""
        # Remove menu items
        for action in self.actions:
            self.iface.removePluginMenu(self.menu_name, action)
        self.actions = []
        
        # Remove toolbar
        if self.toolbar:
            del self.toolbar
            self.toolbar = None
        
        # Remove provider
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
    
    def open_tool_dialog(self):
        """Open the main processing tool dialog."""
        # Check dependencies first
        missing_req, _ = get_missing_packages()
        
        if missing_req:
            reply = QMessageBox.question(
                self.iface.mainWindow(),
                "Dependencies Required",
                "TerraClimate Downloader requires additional Python packages to be installed.\n\n"
                f"Missing packages: {', '.join([m for m, _ in missing_req])}\n\n"
                "Would you like to open the dependency installer?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes
            )
            if reply == QMessageBox.Yes:
                self.show_installer_dialog()
            return
        
        # Open processing dialog
        try:
            import processing
            alg_id = f"{PLUGIN_PROVIDER_ID}:terraclimate_clip_remote_to_layer_gdalclip"
            processing.execAlgorithmDialog(alg_id, {})
        except Exception as e:
            self.iface.messageBar().pushMessage(
                "TerraClimate Downloader",
                f"Could not open dialog: {e}. Try the Processing Toolbox instead.",
                level=Qgis.Warning,
                duration=5
            )
    
    def show_installer_dialog(self):
        """Show the dependency installer dialog."""
        dialog = DependencyInstallerDialog(self.iface.mainWindow())
        dialog.exec_()
        
        # Reload provider to pick up newly installed packages
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = TerraClimateProvider()
            QgsApplication.processingRegistry().addProvider(self.provider)
    
    def show_help(self):
        """Show help/about dialog."""
        help_text = f"""
        <h2>TerraClimate Downloader v{PLUGIN_VERSION}</h2>
        <p><b>Author:</b> Hemed Lungo</p>
        <p><b>Email:</b> Hemedlungo@gmail.com</p>
        
        <h3>Description</h3>
        <p>Download and clip TerraClimate climate data for any region on Earth.</p>
        
        <h3>How to Use</h3>
        <ol>
            <li>First, install dependencies via Plugins → TerraClimate Downloader → Install Dependencies</li>
            <li>Load a polygon layer (your area of interest)</li>
            <li>Open the tool from Plugins menu or Processing Toolbox</li>
            <li>Select your variable, year, and output location</li>
            <li>Run!</li>
        </ol>
        
        <h3>Available Variables</h3>
        <ul>
            <li>Temperature (max/min)</li>
            <li>Precipitation</li>
            <li>Evapotranspiration (actual/potential)</li>
            <li>Soil moisture, runoff, and more...</li>
        </ul>
        
        <h3>Data Range</h3>
        <p>1958 - 2024, monthly resolution</p>
        
        <h3>Links</h3>
        <p>
            <a href="https://github.com/Heed725/Terraclimate_QGIS_Plugin/">GitHub Repository</a><br>
            <a href="https://www.climatologylab.org/terraclimate.html">TerraClimate Dataset</a>
        </p>
        
        <h3>Credits</h3>
        <p>Icon by Fusion5085</p>
        <p>TerraClimate dataset: Abatzoglou et al. (2018), Scientific Data</p>
        """
        
        QMessageBox.about(
            self.iface.mainWindow(),
            "About TerraClimate Downloader",
            help_text
        )
