# -*- coding: utf-8 -*-
def classFactory(iface):
    from .terraclimate_provider import TerraClimateProviderPlugin
    return TerraClimateProviderPlugin(iface)
